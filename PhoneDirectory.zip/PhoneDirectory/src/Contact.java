
import java.util.GregorianCalendar;

public class Contact {
	private String fName;
	private String lName;
	private String[] phoneNum;
	private String affiliation;
	private String occupation;
	private String note = "";
	private GregorianCalendar dob;
	private boolean blocked = false;

	public Contact() {
		this.phoneNum = new String[3];
	}

	public Contact(String fName, String lName, String[] phoneNum, String affiliation, String occupation, String note,
			GregorianCalendar dob) {
		this.fName = fName;
		this.lName = lName;
		this.phoneNum = phoneNum;
		this.affiliation = affiliation;
		this.occupation = occupation;
		this.note = note;
		this.dob = dob;
	}

	public Contact(String fName, String lName) {
		this.fName = fName;
		this.lName = lName;
		this.phoneNum = new String[3];
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public void setPhoneNum(String[] phoneNum) {
		this.phoneNum = phoneNum;
	}

	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public void setDob(GregorianCalendar dob) {
		this.dob = dob;
	}

	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}

	public String getfName() {
		return fName;
	}

	public String getlName() {
		return lName;
	}

	public String[] getPhoneNum() {
		return phoneNum;
	}

	public String getAffiliation() {
		return affiliation;
	}

	public String getOccupation() {
		return occupation;
	}

	public String getNote() {
		return note;
	}

	public GregorianCalendar getDob() {
		return dob;
	}

	public boolean isBlocked() {
		return blocked;
	}

    public void replaceNumber(String oldNumber, String newNumber) {
        for (int i = 0; i < phoneNum.length; i++) {
            if (phoneNum[i] != null && phoneNum[i].equals(oldNumber)) {
                phoneNum[i] = newNumber;
                break;
            }
        }
    }

    public String toString() {
        String result = "Name: " + fName + " " + lName ;
        result += "Phone Numbers: ";
        for (String num : phoneNum) {
            if (num != null) 
            	result += num + " ";
        }
        result += "\nAffiliation: " + affiliation ;
        result += "Occupation: " + occupation ;
        result += "Note: " + note ;
        result += "Date of Birth: " + dob.getTime() ;
        result += "Blocked: " + blocked ;
        return result;
    }
}


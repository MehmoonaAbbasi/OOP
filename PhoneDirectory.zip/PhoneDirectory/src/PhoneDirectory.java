import java.util.ArrayList;
import java.util.GregorianCalendar;

public class PhoneDirectory {
	private ArrayList<Contact>contacts,	contact=new ArrayList<>();

	private ArrayList<Contact> PhoneDirectory;
	private int num;

	public PhoneDirectory() {
		this.PhoneDirectory = new ArrayList<>();
		this.num = 0;
	}

	public PhoneDirectory(ArrayList<Contact> PhoneDirectory) {
		this.PhoneDirectory = PhoneDirectory;
		this.num = PhoneDirectory.size();
	}

	public void setPhoneDirectory(ArrayList<Contact> directory) {
		this.PhoneDirectory = PhoneDirectory;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public ArrayList<Contact> getDirectory() {
		return PhoneDirectory;
	}

	public int getNum() {
		return num;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Contact contact : PhoneDirectory) {
			sb.append(contact.toString()).append("\n");
		}
		return sb.toString();
	}

	public void addContact(Contact c) {
		PhoneDirectory.add(c);
		num++;
	}

	public void addContact(String f, String l, String[] p, String a, String o, String n, GregorianCalendar dob) {
		Contact newContact = new Contact(f, l, p, a, o, n, dob);
		addContact(newContact);
	}

	public Contact search(String firstName) {
		for (Contact contact : PhoneDirectory) {
			if (contact.getfName().equalsIgnoreCase(firstName)) {
				return contact;
			}
		}
		return null;
	}

	public boolean deleteContact(String firstName) {
		for (int i = 0; i < PhoneDirectory.size(); i++) {
			if (PhoneDirectory.get(i).getfName().equalsIgnoreCase(firstName)) {
				PhoneDirectory.remove(i);
				num--;
				return true;
			}
		}
		return false;
	}

	public static void newContact(String fName, String lName, String phoneNumbers, String affiliation,
			String occupation, String note, GregorianCalendar dob) {
		
		
	}
}

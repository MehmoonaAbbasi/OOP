import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class TestApplication {
    public static void main(String[] args) {
        PhoneDirectory directory = new  PhoneDirectory(); 
        Scanner scanner = new Scanner(System.in);
            System.out.println("Phone Directory Menu:");
            System.out.println("1. Add Contact"+"\n"+"2. Search Contact"+"\n"+"3. Delete a Contact"+"\n"+"4. Replace a Number"+"\n"+"5. Display All Contacts"+"\n"+"6. Block a Number"+"\n"+"0. Exit");
            
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
				System.out.print("MehEnter First Name: ");
				String fName = scanner.nextLine();
				System.out.print("MehEnter Last Name: ");
				String lName = scanner.nextLine();
				System.out.print("MehEnter Phone Numbers: ");
				String phoneNumbers = scanner.nextLine();
				System.out.print("MehEnter Affiliation: ");
				String affiliation = scanner.nextLine();
				System.out.print("MehEnter Occupation: ");
				String occupation = scanner.nextLine();
				System.out.print("MehEnter Note: ");
				String note = scanner.nextLine();
				System.out.print("MehEnter Year of Birth: ");
				int year = scanner.nextInt();
				System.out.print("MehEnter Month of Birth (1-12): ");
				int month = scanner.nextInt() - 1;
				System.out.print("MehEnter Day of Birth: ");
				int day = scanner.nextInt();
				GregorianCalendar dob = new GregorianCalendar();
				PhoneDirectory.newContact(fName, lName, phoneNumbers, affiliation, occupation, note, dob);
				System.out.println("Contact added successfully!");
			} else if (choice == 2) {
				System.out.print("Enter First Name to Search: ");
				String searchName = scanner.nextLine();
				Contact foundContact = directory.search(searchName);
				if (foundContact != null) {
				    System.out.println("Contact Found:\n" + foundContact);
				} else {
				    System.out.println("Contact not found.");
				}
			} else if (choice == 3) {
				System.out.print("Enter First Name to Delete: ");
				String deleteName = scanner.nextLine();
				boolean deleted = directory.deleteContact(deleteName);
				if (deleted) {
				    System.out.println("Contact deleted successfully!");
				} else {
				    System.out.println("Contact not found.");
				}
			} else if (choice == 4) {
				System.out.print("Enter First Name to Replace Number: ");
				String replaceName = scanner.nextLine();
				System.out.print("Enter Old Number: ");
				String oldNumber = scanner.nextLine();
				System.out.print("Enter New Number: ");
				String newNumber = scanner.nextLine();
				Contact contactToReplace = directory.search(replaceName);
				if (contactToReplace != null) {
				    contactToReplace.replaceNumber(oldNumber, newNumber);
				    System.out.println("Number replaced successfully!");
				} else {
				    System.out.println("Contact not found.");
				}
			} else if (choice == 5) {
				System.out.println("All Contacts:" + directory);
			} else if (choice == 6) {
				System.out.print("Enter First Name to Block: ");
				String blockName = scanner.nextLine();
				Contact contactToBlock = directory.search(blockName);
				if (contactToBlock != null) {
				    contactToBlock.setBlocked(true);
				    System.out.println("Contact blocked successfully!");
				} else {
				    System.out.println("Contact not found.");
				}
			} else if (choice == 0) {
				System.out.println("Exiting the application.");
			} else {
				System.out.println("Invalid choice. Please try again.");
			}
    }}
    
    
